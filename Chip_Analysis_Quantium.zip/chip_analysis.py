"""
Quantium Virtual Internship - Retail Analytics
Chip Category Analysis
Author: David Olutunde Daniel
Date: February 2026
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime, timedelta
import re
import warnings
warnings.filterwarnings('ignore')

# Set visualization style
sns.set_style("whitegrid")
plt.rcParams['figure.figsize'] = (12, 6)

print("="*80)
print("QUANTIUM RETAIL ANALYTICS - CHIP CATEGORY ANALYSIS")
print("="*80)

# ==============================================================================
# SECTION 1: DATA LOADING AND INITIAL EXPLORATION
# ==============================================================================

print("\n1. LOADING DATA...")
purchase_behaviour = pd.read_csv('/mnt/user-data/uploads/QVI_purchase_behaviour.csv')
transaction_data = pd.read_excel('/mnt/user-data/uploads/QVI_transaction_data.xlsx')

print(f"   Purchase Behaviour: {purchase_behaviour.shape[0]} rows, {purchase_behaviour.shape[1]} columns")
print(f"   Transaction Data: {transaction_data.shape[0]} rows, {transaction_data.shape[1]} columns")

# ==============================================================================
# SECTION 2: DATA QUALITY CHECKS AND CLEANING
# ==============================================================================

print("\n2. DATA QUALITY CHECKS...")

# Convert DATE from Excel serial to datetime
print("   Converting date format...")
transaction_data['DATE'] = pd.to_datetime('1899-12-30') + pd.to_timedelta(transaction_data['DATE'], 'D')

# Check for missing values
print(f"   Missing values in purchase_behaviour: {purchase_behaviour.isnull().sum().sum()}")
print(f"   Missing values in transaction_data: {transaction_data.isnull().sum().sum()}")

# Check for duplicates
print(f"   Duplicate loyalty cards: {purchase_behaviour['LYLTY_CARD_NBR'].duplicated().sum()}")
print(f"   Duplicate transactions: {transaction_data['TXN_ID'].duplicated().sum()}")

# Identify and remove outliers
print("\n   Checking for outliers in PROD_QTY...")
print(f"   Transactions with PROD_QTY > 5: {(transaction_data['PROD_QTY'] > 5).sum()}")

# Examine the outlier transactions
outliers = transaction_data[transaction_data['PROD_QTY'] == 200]
print(f"\n   Found {len(outliers)} transactions with PROD_QTY = 200")
print("   These appear to be data errors and will be removed")

# Remove outliers
transaction_data_clean = transaction_data[transaction_data['PROD_QTY'] != 200].copy()
print(f"   Cleaned data: {transaction_data_clean.shape[0]} rows")

# ==============================================================================
# SECTION 3: FEATURE ENGINEERING
# ==============================================================================

print("\n3. FEATURE ENGINEERING...")

# Extract pack size from product name
def extract_pack_size(prod_name):
    """Extract numeric pack size from product name"""
    match = re.search(r'(\d+)g', prod_name, re.IGNORECASE)
    if match:
        return int(match.group(1))
    return None

transaction_data_clean['PACK_SIZE'] = transaction_data_clean['PROD_NAME'].apply(extract_pack_size)

# Extract brand name
def extract_brand(prod_name):
    """Extract brand name from product name"""
    # Common brands to look for
    brands = ['Smiths', 'Doritos', 'Kettle', 'Pringles', 'Thins', 'CCs', 'Cheezels', 
              'Twisties', 'Grain Waves', 'Natural', 'Old El Paso', 'WW', 'Woolworths',
              'Red Rock Deli', 'Infuzions', 'Burger Rings', 'French Fries', 'NCC',
              'Dorito', 'Cheetos', 'Cobs', 'Sunbites', 'Snbts', 'Tyrrells', 'Tostitos',
              'RRD', 'GrnWves', 'Infzns']
    
    # Check each brand
    for brand in brands:
        if brand.lower() in prod_name.lower():
            return brand
    
    # If no brand found, return first word
    return prod_name.split()[0]

transaction_data_clean['BRAND'] = transaction_data_clean['PROD_NAME'].apply(extract_brand)

print(f"   Pack sizes extracted: {transaction_data_clean['PACK_SIZE'].notna().sum()} products")
print(f"   Unique brands identified: {transaction_data_clean['BRAND'].nunique()}")

# Check for non-chip products
print("\n   Checking for non-chip products (salsa)...")
salsa_products = transaction_data_clean[transaction_data_clean['PROD_NAME'].str.contains('Salsa', case=False, na=False)]
print(f"   Found {len(salsa_products)} salsa transactions")
print("   Removing salsa products as they are not chips...")
transaction_data_clean = transaction_data_clean[~transaction_data_clean['PROD_NAME'].str.contains('Salsa', case=False, na=False)]

print(f"   Final cleaned data: {transaction_data_clean.shape[0]} rows")

# ==============================================================================
# SECTION 4: MERGE DATASETS
# ==============================================================================

print("\n4. MERGING TRANSACTION AND CUSTOMER DATA...")

# Merge datasets
data = transaction_data_clean.merge(purchase_behaviour, on='LYLTY_CARD_NBR', how='left')

print(f"   Merged dataset: {data.shape[0]} rows, {data.shape[1]} columns")

# Check for customers without segment information
customers_without_segment = data['LIFESTAGE'].isnull().sum()
print(f"   Transactions without customer segment: {customers_without_segment}")

# ==============================================================================
# SECTION 5: CALCULATE KEY METRICS
# ==============================================================================

print("\n5. CALCULATING KEY METRICS...")

# Add derived metrics
data['UNIT_PRICE'] = data['TOT_SALES'] / data['PROD_QTY']

# Create customer segments
data['CUSTOMER_SEGMENT'] = data['LIFESTAGE'] + ' - ' + data['PREMIUM_CUSTOMER']

print("   Key metrics created:")
print("   - UNIT_PRICE")
print("   - CUSTOMER_SEGMENT")

# ==============================================================================
# SECTION 6: DESCRIPTIVE ANALYSIS
# ==============================================================================

print("\n6. DESCRIPTIVE ANALYSIS...")

# Overall summary statistics
print("\n   Overall Summary:")
print(f"   Total Transactions: {len(data):,}")
print(f"   Total Sales: ${data['TOT_SALES'].sum():,.2f}")
print(f"   Total Units Sold: {data['PROD_QTY'].sum():,}")
print(f"   Average Transaction Value: ${data['TOT_SALES'].mean():.2f}")
print(f"   Average Unit Price: ${data['UNIT_PRICE'].mean():.2f}")
print(f"   Unique Customers: {data['LYLTY_CARD_NBR'].nunique():,}")
print(f"   Date Range: {data['DATE'].min().strftime('%Y-%m-%d')} to {data['DATE'].max().strftime('%Y-%m-%d')}")

# Sales by customer segment
print("\n   Sales by Customer Segment:")
segment_analysis = data.groupby('CUSTOMER_SEGMENT').agg({
    'TOT_SALES': ['sum', 'mean', 'count'],
    'PROD_QTY': 'sum',
    'LYLTY_CARD_NBR': 'nunique'
}).round(2)

segment_analysis.columns = ['Total_Sales', 'Avg_Transaction', 'Num_Transactions', 'Total_Units', 'Unique_Customers']
segment_analysis = segment_analysis.sort_values('Total_Sales', ascending=False)
print(segment_analysis.head(10))

# Sales by LIFESTAGE
print("\n   Sales by Lifestage:")
lifestage_analysis = data.groupby('LIFESTAGE').agg({
    'TOT_SALES': ['sum', 'mean'],
    'PROD_QTY': 'sum',
    'LYLTY_CARD_NBR': 'nunique'
}).round(2)
lifestage_analysis.columns = ['Total_Sales', 'Avg_Transaction', 'Total_Units', 'Unique_Customers']
lifestage_analysis = lifestage_analysis.sort_values('Total_Sales', ascending=False)
print(lifestage_analysis)

# Sales by PREMIUM_CUSTOMER
print("\n   Sales by Premium Customer Type:")
premium_analysis = data.groupby('PREMIUM_CUSTOMER').agg({
    'TOT_SALES': ['sum', 'mean'],
    'PROD_QTY': 'sum',
    'LYLTY_CARD_NBR': 'nunique'
}).round(2)
premium_analysis.columns = ['Total_Sales', 'Avg_Transaction', 'Total_Units', 'Unique_Customers']
print(premium_analysis)

# Brand analysis
print("\n   Top 10 Brands by Sales:")
brand_analysis = data.groupby('BRAND').agg({
    'TOT_SALES': 'sum',
    'PROD_QTY': 'sum'
}).sort_values('TOT_SALES', ascending=False).head(10)
print(brand_analysis)

# Pack size analysis
print("\n   Sales by Pack Size:")
packsize_analysis = data.groupby('PACK_SIZE').agg({
    'TOT_SALES': 'sum',
    'PROD_QTY': 'sum'
}).sort_values('TOT_SALES', ascending=False)
print(packsize_analysis.head(10))

# ==============================================================================
# SECTION 7: CUSTOMER BEHAVIOR ANALYSIS
# ==============================================================================

print("\n7. CUSTOMER BEHAVIOR ANALYSIS...")

# Customer purchase frequency
customer_freq = data.groupby('LYLTY_CARD_NBR').agg({
    'TXN_ID': 'count',
    'TOT_SALES': 'sum',
    'PROD_QTY': 'sum',
    'LIFESTAGE': 'first',
    'PREMIUM_CUSTOMER': 'first'
}).rename(columns={'TXN_ID': 'Num_Transactions'})

print(f"\n   Average transactions per customer: {customer_freq['Num_Transactions'].mean():.2f}")
print(f"   Average total spend per customer: ${customer_freq['TOT_SALES'].mean():.2f}")
print(f"   Average units per customer: {customer_freq['PROD_QTY'].mean():.2f}")

# Frequency by segment
freq_by_segment = customer_freq.groupby(['LIFESTAGE', 'PREMIUM_CUSTOMER']).agg({
    'Num_Transactions': 'mean',
    'TOT_SALES': 'mean',
    'PROD_QTY': 'mean'
}).round(2)
freq_by_segment.columns = ['Avg_Transactions_Per_Customer', 'Avg_Spend_Per_Customer', 'Avg_Units_Per_Customer']
freq_by_segment = freq_by_segment.sort_values('Avg_Spend_Per_Customer', ascending=False)

print("\n   Average Customer Metrics by Segment (Top 10):")
print(freq_by_segment.head(10))

# ==============================================================================
# SECTION 8: DEEP DIVE - KEY INSIGHTS
# ==============================================================================

print("\n8. KEY INSIGHTS - DEEP DIVE...")

# Who are the biggest spenders?
print("\n   A. HIGHEST VALUE SEGMENTS (by total sales):")
top_segments = segment_analysis.head(3)
for idx, row in top_segments.iterrows():
    print(f"\n   {idx}:")
    print(f"      Total Sales: ${row['Total_Sales']:,.2f}")
    print(f"      Unique Customers: {int(row['Unique_Customers']):,}")
    print(f"      Avg Transaction: ${row['Avg_Transaction']:.2f}")
    print(f"      Total Transactions: {int(row['Num_Transactions']):,}")

# Which segments buy most frequently?
print("\n   B. MOST FREQUENT BUYERS (by avg transactions per customer):")
most_frequent = freq_by_segment.sort_values('Avg_Transactions_Per_Customer', ascending=False).head(3)
for idx, row in most_frequent.iterrows():
    print(f"\n   {idx}:")
    print(f"      Avg Transactions per Customer: {row['Avg_Transactions_Per_Customer']:.2f}")
    print(f"      Avg Spend per Customer: ${row['Avg_Spend_Per_Customer']:.2f}")

# Pack size preferences by segment
print("\n   C. PACK SIZE PREFERENCES BY TOP SEGMENTS:")
top_3_segments = segment_analysis.head(3).index.tolist()

for segment in top_3_segments:
    segment_data = data[data['CUSTOMER_SEGMENT'] == segment]
    pack_pref = segment_data.groupby('PACK_SIZE')['PROD_QTY'].sum().sort_values(ascending=False).head(3)
    print(f"\n   {segment}:")
    for pack_size, qty in pack_pref.items():
        pct = (qty / segment_data['PROD_QTY'].sum()) * 100
        print(f"      {pack_size}g: {int(qty):,} units ({pct:.1f}%)")

# Brand preferences by segment
print("\n   D. BRAND PREFERENCES BY TOP SEGMENTS:")
for segment in top_3_segments:
    segment_data = data[data['CUSTOMER_SEGMENT'] == segment]
    brand_pref = segment_data.groupby('BRAND')['TOT_SALES'].sum().sort_values(ascending=False).head(3)
    print(f"\n   {segment}:")
    for brand, sales in brand_pref.items():
        pct = (sales / segment_data['TOT_SALES'].sum()) * 100
        print(f"      {brand}: ${sales:,.2f} ({pct:.1f}%)")

# ==============================================================================
# SECTION 9: SAVE CLEANED DATA
# ==============================================================================

print("\n9. SAVING CLEANED DATA AND RESULTS...")

# Save cleaned transaction data
data.to_csv('/home/claude/cleaned_transaction_data.csv', index=False)
print("   ✓ Cleaned transaction data saved")

# Save segment analysis
segment_analysis.to_csv('/home/claude/segment_analysis.csv')
print("   ✓ Segment analysis saved")

# Save customer frequency analysis
freq_by_segment.to_csv('/home/claude/customer_frequency_analysis.csv')
print("   ✓ Customer frequency analysis saved")

# Save brand analysis
brand_analysis.to_csv('/home/claude/brand_analysis.csv')
print("   ✓ Brand analysis saved")

# Save pack size analysis
packsize_analysis.to_csv('/home/claude/packsize_analysis.csv')
print("   ✓ Pack size analysis saved")

print("\n" + "="*80)
print("DATA CLEANING AND INITIAL ANALYSIS COMPLETE")
print("="*80)
