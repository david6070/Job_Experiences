"""
Natural Gas Storage Contract Pricing Model
JPMorgan Chase Quantitative Research Task

Author: David Olutunde Daniel
Date: February 8, 2026

This script analyzes historical natural gas prices and provides price estimates
for any date (historical or future) based on seasonal trends and time series analysis.
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from datetime import datetime, timedelta
from scipy.interpolate import interp1d
from sklearn.linear_model import LinearRegression
import warnings
warnings.filterwarnings('ignore')


class NaturalGasPriceModel:
    """
    A model for estimating natural gas prices based on historical data
    and seasonal patterns.
    """
    
    def __init__(self, csv_path):
        """
        Initialize the model with historical price data.
        
        Args:
            csv_path: Path to the CSV file containing historical prices
        """
        self.df = self._load_data(csv_path)
        self.seasonal_model = None
        self.trend_model = None
        self._fit_models()
        
    def _load_data(self, csv_path):
        """Load and preprocess the natural gas price data."""
        df = pd.read_csv(csv_path)
        
        # Convert dates to datetime
        df['Dates'] = pd.to_datetime(df['Dates'])
        
        # Convert prices from scientific notation to float
        df['Prices'] = df['Prices'].astype(float)
        
        # Sort by date
        df = df.sort_values('Dates').reset_index(drop=True)
        
        # Extract useful features
        df['Year'] = df['Dates'].dt.year
        df['Month'] = df['Dates'].dt.month
        df['Days_Since_Start'] = (df['Dates'] - df['Dates'].min()).dt.days
        
        return df
    
    def _fit_models(self):
        """Fit seasonal and trend models to the data."""
        # Calculate average price by month (seasonal component)
        self.monthly_avg = self.df.groupby('Month')['Prices'].mean()
        
        # Fit linear trend
        X = self.df['Days_Since_Start'].values.reshape(-1, 1)
        y = self.df['Prices'].values
        self.trend_model = LinearRegression()
        self.trend_model.fit(X, y)
        
        # Calculate detrended prices for better seasonal analysis
        trend_prices = self.trend_model.predict(X)
        self.df['Detrended_Prices'] = self.df['Prices'] - trend_prices
        
        # Recalculate seasonal component from detrended data
        self.seasonal_component = self.df.groupby('Month')['Detrended_Prices'].mean()
        
    def analyze_seasonality(self):
        """
        Analyze and visualize seasonal patterns in natural gas prices.
        
        Returns:
            Dictionary containing seasonal analysis results
        """
        print("=" * 80)
        print("NATURAL GAS PRICE SEASONALITY ANALYSIS")
        print("=" * 80)
        
        # Monthly statistics
        monthly_stats = self.df.groupby('Month')['Prices'].agg(['mean', 'std', 'min', 'max'])
        monthly_stats.index = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 
                               'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
        
        print("\nMonthly Price Statistics:")
        print(monthly_stats.round(2))
        
        # Identify seasonal patterns
        highest_month = monthly_stats['mean'].idxmax()
        lowest_month = monthly_stats['mean'].idxmin()
        
        print(f"\nKey Findings:")
        print(f"- Highest average prices: {highest_month} (${monthly_stats.loc[highest_month, 'mean']:.2f})")
        print(f"- Lowest average prices: {lowest_month} (${monthly_stats.loc[lowest_month, 'mean']:.2f})")
        print(f"- Seasonal variation: ${monthly_stats['mean'].max() - monthly_stats['mean'].min():.2f}")
        
        # Overall trend
        trend_coef = self.trend_model.coef_[0]
        annual_trend = trend_coef * 365
        print(f"- Annual price trend: ${annual_trend:.2f} per year")
        
        return {
            'monthly_stats': monthly_stats,
            'highest_month': highest_month,
            'lowest_month': lowest_month,
            'annual_trend': annual_trend
        }
    
    def visualize_data(self, save_path='/home/claude/nat_gas_analysis.png'):
        """
        Create comprehensive visualizations of the natural gas price data.
        
        Args:
            save_path: Path to save the visualization
        """
        fig, axes = plt.subplots(2, 2, figsize=(16, 12))
        fig.suptitle('Natural Gas Price Analysis', fontsize=16, fontweight='bold')
        
        # 1. Historical prices with trend
        ax1 = axes[0, 0]
        ax1.plot(self.df['Dates'], self.df['Prices'], 'o-', label='Actual Prices', 
                linewidth=2, markersize=4, color='steelblue')
        
        # Add trend line
        trend_line = self.trend_model.predict(self.df['Days_Since_Start'].values.reshape(-1, 1))
        ax1.plot(self.df['Dates'], trend_line, '--', label='Linear Trend', 
                linewidth=2, color='red', alpha=0.7)
        
        ax1.set_xlabel('Date', fontsize=11)
        ax1.set_ylabel('Price ($/MMBtu)', fontsize=11)
        ax1.set_title('Historical Natural Gas Prices (Oct 2020 - Sep 2024)', fontsize=12, fontweight='bold')
        ax1.legend()
        ax1.grid(True, alpha=0.3)
        ax1.tick_params(axis='x', rotation=45)
        
        # 2. Seasonal pattern (average by month)
        ax2 = axes[0, 1]
        months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 
                 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
        monthly_avg = self.df.groupby('Month')['Prices'].mean()
        
        colors = ['red' if x == monthly_avg.max() else 'green' if x == monthly_avg.min() 
                 else 'steelblue' for x in monthly_avg]
        
        ax2.bar(range(1, 13), monthly_avg.values, color=colors, alpha=0.7, edgecolor='black')
        ax2.set_xlabel('Month', fontsize=11)
        ax2.set_ylabel('Average Price ($/MMBtu)', fontsize=11)
        ax2.set_title('Seasonal Price Pattern (Monthly Averages)', fontsize=12, fontweight='bold')
        ax2.set_xticks(range(1, 13))
        ax2.set_xticklabels(months)
        ax2.grid(True, alpha=0.3, axis='y')
        
        # Add value labels on bars
        for i, v in enumerate(monthly_avg.values):
            ax2.text(i+1, v + 0.1, f'${v:.2f}', ha='center', va='bottom', fontsize=9)
        
        # 3. Year-over-year comparison
        ax3 = axes[1, 0]
        years = self.df['Year'].unique()
        for year in years:
            year_data = self.df[self.df['Year'] == year]
            ax3.plot(year_data['Month'], year_data['Prices'], 'o-', 
                    label=str(year), linewidth=2, markersize=6)
        
        ax3.set_xlabel('Month', fontsize=11)
        ax3.set_ylabel('Price ($/MMBtu)', fontsize=11)
        ax3.set_title('Year-over-Year Price Comparison', fontsize=12, fontweight='bold')
        ax3.set_xticks(range(1, 13))
        ax3.set_xticklabels(months)
        ax3.legend(title='Year')
        ax3.grid(True, alpha=0.3)
        
        # 4. Price distribution and statistics
        ax4 = axes[1, 1]
        ax4.hist(self.df['Prices'], bins=20, color='steelblue', alpha=0.7, edgecolor='black')
        ax4.axvline(self.df['Prices'].mean(), color='red', linestyle='--', 
                   linewidth=2, label=f'Mean: ${self.df["Prices"].mean():.2f}')
        ax4.axvline(self.df['Prices'].median(), color='green', linestyle='--', 
                   linewidth=2, label=f'Median: ${self.df["Prices"].median():.2f}')
        
        ax4.set_xlabel('Price ($/MMBtu)', fontsize=11)
        ax4.set_ylabel('Frequency', fontsize=11)
        ax4.set_title('Price Distribution', fontsize=12, fontweight='bold')
        ax4.legend()
        ax4.grid(True, alpha=0.3, axis='y')
        
        # Add statistics text
        stats_text = f'Std Dev: ${self.df["Prices"].std():.2f}\nMin: ${self.df["Prices"].min():.2f}\nMax: ${self.df["Prices"].max():.2f}'
        ax4.text(0.95, 0.95, stats_text, transform=ax4.transAxes, 
                verticalalignment='top', horizontalalignment='right',
                bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5),
                fontsize=10)
        
        plt.tight_layout()
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        print(f"\nVisualization saved to: {save_path}")
        
        return fig
    
    def estimate_price(self, target_date):
        """
        Estimate natural gas price for any given date.
        
        This method uses a combination of:
        1. Linear trend from historical data
        2. Seasonal adjustment based on month
        3. Interpolation for dates within historical range
        
        Args:
            target_date: Date string (e.g., '2025-06-15') or datetime object
            
        Returns:
            Estimated price as float
        """
        # Convert string to datetime if needed
        if isinstance(target_date, str):
            target_date = pd.to_datetime(target_date)
        
        # Calculate days since start
        days_since_start = (target_date - self.df['Dates'].min()).days
        
        # Get base trend price
        base_price = self.trend_model.predict([[days_since_start]])[0]
        
        # Get seasonal adjustment
        month = target_date.month
        seasonal_adj = self.seasonal_component[month]
        
        # Combine trend and seasonal components
        estimated_price = base_price + seasonal_adj
        
        # For dates within historical range, use weighted average with interpolation
        if self.df['Dates'].min() <= target_date <= self.df['Dates'].max():
            # Find nearest dates
            dates_numeric = self.df['Days_Since_Start'].values
            prices = self.df['Prices'].values
            
            # Use linear interpolation
            interpolator = interp1d(dates_numeric, prices, kind='linear', 
                                   fill_value='extrapolate')
            interpolated_price = interpolator(days_since_start)
            
            # Weight more heavily towards interpolation for historical dates
            estimated_price = 0.7 * interpolated_price + 0.3 * estimated_price
        
        return float(estimated_price)
    
    def extrapolate_future(self, months_ahead=12):
        """
        Extrapolate prices for future months.
        
        Args:
            months_ahead: Number of months to extrapolate (default: 12)
            
        Returns:
            DataFrame with future dates and estimated prices
        """
        last_date = self.df['Dates'].max()
        
        future_dates = []
        future_prices = []
        
        for i in range(1, months_ahead + 1):
            # Calculate the future date (end of each month)
            future_date = last_date + pd.DateOffset(months=i)
            # Adjust to end of month
            future_date = pd.Timestamp(future_date.year, future_date.month, 
                                      pd.Period(future_date, freq='M').days_in_month)
            
            future_dates.append(future_date)
            future_prices.append(self.estimate_price(future_date))
        
        future_df = pd.DataFrame({
            'Date': future_dates,
            'Estimated_Price': future_prices
        })
        
        return future_df
    
    def generate_report(self):
        """Generate a comprehensive report of the analysis."""
        print("\n" + "=" * 80)
        print("NATURAL GAS PRICE ESTIMATION MODEL - COMPREHENSIVE REPORT")
        print("=" * 80)
        
        print(f"\nData Range: {self.df['Dates'].min().strftime('%B %d, %Y')} to "
              f"{self.df['Dates'].max().strftime('%B %d, %Y')}")
        print(f"Total Observations: {len(self.df)}")
        
        # Seasonality analysis
        analysis = self.analyze_seasonality()
        
        # Future extrapolation
        print("\n" + "-" * 80)
        print("FUTURE PRICE EXTRAPOLATION (Next 12 Months)")
        print("-" * 80)
        
        future_df = self.extrapolate_future(12)
        print("\n", future_df.to_string(index=False))
        
        # Model performance on historical data
        print("\n" + "-" * 80)
        print("MODEL VALIDATION")
        print("-" * 80)
        
        predictions = [self.estimate_price(date) for date in self.df['Dates']]
        actual = self.df['Prices'].values
        
        mae = np.mean(np.abs(np.array(predictions) - actual))
        rmse = np.sqrt(np.mean((np.array(predictions) - actual) ** 2))
        mape = np.mean(np.abs((actual - np.array(predictions)) / actual)) * 100
        
        print(f"\nBacktesting Statistics:")
        print(f"- Mean Absolute Error (MAE): ${mae:.2f}")
        print(f"- Root Mean Square Error (RMSE): ${rmse:.2f}")
        print(f"- Mean Absolute Percentage Error (MAPE): {mape:.2f}%")
        
        print("\n" + "=" * 80)
        
        return future_df


def main():
    """Main function to run the natural gas pricing analysis."""
    
    # Initialize the model
    print("Loading natural gas price data...")
    model = NaturalGasPriceModel('/mnt/user-data/uploads/Nat_Gas.csv')
    
    # Generate visualizations
    print("\nGenerating visualizations...")
    model.visualize_data()
    
    # Generate comprehensive report
    future_prices = model.generate_report()
    
    # Example: Estimate prices for specific dates
    print("\n" + "=" * 80)
    print("EXAMPLE PRICE ESTIMATES")
    print("=" * 80)
    
    example_dates = [
        '2023-06-15',  # Historical date (summer)
        '2024-01-15',  # Historical date (winter)
        '2024-12-31',  # Near future
        '2025-06-30',  # Mid-term future (summer)
        '2025-12-31',  # Long-term future (winter)
    ]
    
    print("\n{:<20} {:<15}".format("Date", "Estimated Price"))
    print("-" * 40)
    for date_str in example_dates:
        price = model.estimate_price(date_str)
        date_obj = pd.to_datetime(date_str)
        print(f"{date_obj.strftime('%B %d, %Y'):<20} ${price:>10.2f}")
    
    print("\n" + "=" * 80)
    print("USAGE INSTRUCTIONS")
    print("=" * 80)
    print("""
To use this model for pricing storage contracts:

1. Initialize the model:
   model = NaturalGasPriceModel('path/to/Nat_Gas.csv')

2. Get price estimate for any date:
   price = model.estimate_price('2025-06-15')
   
3. Get extrapolated future prices:
   future_prices = model.extrapolate_future(months_ahead=12)
   
4. The model accounts for:
   - Long-term price trends
   - Seasonal variations (higher in winter, lower in summer)
   - Historical price patterns
   
5. For storage contract pricing:
   - Injection date price: model.estimate_price(injection_date)
   - Withdrawal date price: model.estimate_price(withdrawal_date)
   - Expected profit = (withdrawal_price - injection_price) * quantity - storage_costs
    """)
    
    print("\nAnalysis complete!")
    
    return model, future_prices


if __name__ == "__main__":
    model, future_prices = main()
